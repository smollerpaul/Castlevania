﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace uiuiui
{

    public partial class bcn : UserControl
    {
        private static bcn baocaonam;
        public static bcn Baocaonam
        {
            get
            {
                if (baocaonam == null)
                    baocaonam = new bcn();
                return baocaonam;
            }
        }
        public bcn()
        {
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
