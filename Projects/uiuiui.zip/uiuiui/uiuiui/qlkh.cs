﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace uiuiui
{
    public partial class qlkh : UserControl
    {
        private static qlkh khohang;
        public static qlkh Khohang
        {
            get
            {
                if (khohang == null)
                    khohang = new qlkh();
                return khohang;
            }
        }
        public qlkh()
        {
            InitializeComponent();
        }

        private void KhinsertBtn_Click(object sender, EventArgs e)
        {
           panel2.Enabled = true;
        }
    }
}
